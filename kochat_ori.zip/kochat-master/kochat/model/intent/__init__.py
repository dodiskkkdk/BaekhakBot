"""
@auther Hyunwoong
@since 6/28/2020
@see https://github.com/gusdnd852
"""

from kochat.model.intent.cnn import CNN
from kochat.model.intent.lstm import LSTM

__ALL__ = [CNN, LSTM]
